# game_selling_marketplace
A platform where a gamers can download their favourite games!

# How to run the file
Run the following command to install all the required modules
pip install -r requirements.txt

After installing the requirements.txt file. use python app.py command to execute the server.
launch the browser and type the given local hosted server address.
